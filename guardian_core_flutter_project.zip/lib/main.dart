import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GuardianApp());
}

// バックグラウンドタスク初期化コールバック
@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(GuardianTaskHandler());
}

class GuardianTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    // バックグラウンドサービス起動時のフック
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    // 定期監視
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    // 破棄時クリーンアップ
  }
}

class GuardianApp extends StatelessWidget {
  const GuardianApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Guardian Core',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF10B981),
          secondary: Color(0xFFEF4444),
        ),
      ),
      home: const GuardianHomeScreen(),
    );
  }
}

class GuardianHomeScreen extends StatefulWidget {
  const GuardianHomeScreen({Key? key}) : super(key: key);

  @override
  State<GuardianHomeScreen> createState() => _GuardianHomeScreenState();
}

class _GuardianHomeScreenState extends State<GuardianHomeScreen> {
  // Gemini API Key
  final String _geminiApiKey = "AQ.Ab8RN6Jz0fto_IGwT_0zUcz0ud7KUe8y6G6oqe-VD-5MEi-GYg";

  late stt.SpeechToText _speech;
  bool _isSpeechAvailable = false;
  bool _isListening = false;
  bool _isBackgroundRunning = false;

  String _recognizedText = "周囲の音声を監視していません。";
  String _aiStatus = "SAFE";
  String _aiAnalysisLog = "システム待機中...「監視開始」ボタンを押すかテストを実行してください。";
  bool _isAlertTriggered = false;
  bool _isAnalyzing = false;

  Timer? _continuousRestartTimer;

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _initForegroundTask();
    _initSpeechRecognizer();
  }

  @override
  void dispose() {
    _continuousRestartTimer?.cancel();
    _speech.stop();
    super.dispose();
  }

  // フォアグラウンドタスク（画面OFF時キープ用サービス）の初期化
  void _initForegroundTask() {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'guardian_foreground_service',
        channelName: 'Guardian 防犯AI音声監視',
        channelDescription: 'バックグラウンドで音声と安全文脈を監視しています',
        channelImportance: NotificationChannelImportance.HIGH,
        priority: NotificationPriority.HIGH,
        iconData: const NotificationIconData(
          resType: ResourceType.mipmap,
          resPrefix: ResourcePrefix.ic,
          name: 'launcher',
        ),
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: true,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(5000),
        autoRunOnBoot: true,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }

  // 音声認識の初期化とパーミッション要求
  Future<void> _initSpeechRecognizer() async {
    await [
      Permission.microphone,
      Permission.notification,
      Permission.ignoreBatteryOptimizations,
    ].request();

    bool available = await _speech.initialize(
      onStatus: (status) {
        if (status == 'done' || status == 'notListening') {
          if (_isListening) {
            // バックグラウンド・常時監視を維持するため自動再スタート
            _restartListening();
          }
        }
      },
      onError: (errorNotification) {
        debugPrint('Speech Error: ${errorNotification.errorMsg}');
        if (_isListening) {
          _restartListening();
        }
      },
    );

    setState(() {
      _isSpeechAvailable = available;
    });
  }

  // 自動再リスニング（音声認識セッションの切断を防止）
  void _restartListening() {
    _continuousRestartTimer?.cancel();
    _continuousRestartTimer = Timer(const Duration(milliseconds: 600), () {
      if (mounted && _isListening) {
        _startListeningInternal();
      }
    });
  }

  // 音声監視の開始
  Future<void> _toggleMonitoring() async {
    if (_isListening) {
      // 停止
      await _speech.stop();
      if (_isBackgroundRunning) {
        await FlutterForegroundTask.stopService();
      }
      setState(() {
        _isListening = false;
        _isBackgroundRunning = false;
        _aiAnalysisLog = "音声監視を一時停止しました。";
      });
    } else {
      // 開始
      if (!_isSpeechAvailable) {
        await _initSpeechRecognizer();
      }

      // フォアグラウンド常駐サービスの起動（画面ロック時もCPUをスリープさせない）
      if (!await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.startService(
          serviceId: 256,
          notificationTitle: 'Guardian Core 監視中',
          notificationText: '周囲の音声文脈をリアルタイム監査中',
          callback: startCallback,
        );
        _isBackgroundRunning = true;
      }

      setState(() {
        _isListening = true;
        _recognizedText = "音声を受信中...話してください...";
        _aiAnalysisLog = "常時監視サービス稼働中（画面消灯時もWAKE_LOCK保持）";
      });

      _startListeningInternal();
    }
  }

  void _startListeningInternal() {
    if (!_isSpeechAvailable) return;
    try {
      _speech.listen(
        onResult: (result) {
          setState(() {
            _recognizedText = result.recognizedWords;
          });

          // 認識テキストが確定した、または一定文字数蓄積したらGemini APIへ監査リクエスト
          if (result.finalResult && result.recognizedWords.trim().isNotEmpty) {
            _auditWithGeminiAPI(result.recognizedWords);
          }
        },
        listenMode: stt.ListenMode.dictation,
        partialResults: true,
        localeId: 'ja_JP',
        cancelOnError: false,
      );
    } catch (e) {
      debugPrint("Speech listen error: $e");
    }
  }

  // 模擬テスト: 人身売買・詐欺シナリオ
  void _simulateTraffickingDialogue() {
    const dialogue =
        "未経験でも月収100万円以上保証するよ。まずはカンボジアのポイペト（Poipet）のオフィスに来て。旅費もホテル代も全部こっちで持つから心配いらない。ただ、セキュリティの関係でパスポートと携帯は一度オフィスの金庫で預かるね。会社のルールだから、断るならここから帰すわけにはいかないよ。";
    setState(() {
      _recognizedText = dialogue;
    });
    _auditWithGeminiAPI(dialogue);
  }

  // 模擬テスト: 日常会話
  void _simulateSafeDialogue() {
    const dialogue =
        "今日はオーンと一緒にシェムリアップのアンコールワット近くのカフェで美味しいコーヒーを飲んでいます。天気がとても良くて幸運な一日です。";
    setState(() {
      _recognizedText = dialogue;
    });
    _auditWithGeminiAPI(dialogue);
  }

  // Gemini API による語源・文脈監査
  Future<void> _auditWithGeminiAPI(String text) async {
    if (_isAnalyzing) return;

    setState(() {
      _isAnalyzing = true;
      _aiAnalysisLog = "AI語源・文脈監査を実行中...";
    });

    // 正しいGemini API エンドポイント
    final String url =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$_geminiApiKey";

    final Map<String, dynamic> requestBody = {
      "contents": [
        {
          "parts": [
            {"text": text}
          ]
        }
      ],
      "systemInstruction": {
        "parts": [
          {
            "text":
                "あなたはラックヌンロイバァーン株式会社の防衛AIです。入力されたテキストから人身売買、監禁、AI詐欺の文脈を監査してください。日常会話なら必ず「SAFE」の4文字のみを出力。危険を検知した場合は厳格に以下のJSONフォーマットのみを出力して、前置きは一切書かないでください。{\"status\": \"ALERT\", \"risk_category\": \"犯罪ジャンル\", \"confidence_score\": \"危険度0-1\", \"detected_text_segment\": \"該当テキスト\", \"linguistic_analysis\": \"語源・理由の解説\"}"
          }
        ]
      },
      "generationConfig": {
        "temperature": 0.1,
      }
    };

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        final String aiResponseText = responseData['candidates'][0]['content']['parts'][0]['text'].toString().trim();

        if (aiResponseText.contains("ALERT")) {
          try {
            final startIdx = aiResponseText.indexOf('{');
            final endIdx = aiResponseText.lastIndexOf('}');
            final cleanJson = aiResponseText.substring(startIdx, endIdx + 1);
            final Map<String, dynamic> logData = jsonDecode(cleanJson);

            setState(() {
              _aiStatus = "ALERT";
              _isAlertTriggered = true;
              _aiAnalysisLog =
                  "【⚠️ 証拠ロック完了・特殊部隊出動シグナル】\n\n■ リスク分類: ${logData['risk_category']}\n■ 危険度スコア: ${logData['confidence_score']}\n\n■ 語源・文脈解析:\n${logData['linguistic_analysis']}";
            });
          } catch (_) {
            setState(() {
              _aiStatus = "ALERT";
              _isAlertTriggered = true;
              _aiAnalysisLog = "【⚠️ 証拠ロック完了・特殊部隊出動シグナル】\n\n$aiResponseText";
            });
          }
        } else {
          setState(() {
            _aiStatus = "SAFE";
            _isAlertTriggered = false;
            _aiAnalysisLog = "監査完了: 異常なし（SAFE）\n平和な会話、または犯罪の文脈は含まれていません。";
          });
        }
      } else {
        setState(() {
          _aiAnalysisLog = "APIエラー: ステータスコード ${response.statusCode}\n${response.body}";
        });
      }
    } catch (e) {
      setState(() {
        _aiAnalysisLog = "通信エラーが発生しました: $e";
      });
    } finally {
      setState(() {
        _isAnalyzing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final alertColor = const Color(0xFFEF4444);
    final safeColor = const Color(0xFF10B981);

    return Scaffold(
      backgroundColor: _isAlertTriggered ? const Color(0xFF3F0A0A) : const Color(0xFF121212),
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.shield, color: _isAlertTriggered ? alertColor : safeColor, size: 20),
            const SizedBox(width: 8),
            const Text('Guardian Core v1.0', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
        backgroundColor: Colors.black,
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(_isListening ? Icons.mic : Icons.mic_off,
                color: _isListening ? Colors.redAccent : Colors.grey),
            tooltip: _isListening ? '常時監視中' : '停止中',
            onPressed: _toggleMonitoring,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ステータスカード
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: _isAlertTriggered ? alertColor : safeColor,
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("SYSTEM AUDIT STATUS:",
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Colors.grey)),
                        const SizedBox(height: 2),
                        Text(
                          _isListening ? "常時バックグラウンド監視稼働中" : "監視待機中",
                          style: TextStyle(
                            fontSize: 11,
                            color: _isListening ? Colors.cyanAccent : Colors.white60,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _isAlertTriggered
                            ? alertColor.withOpacity(0.2)
                            : safeColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        _aiStatus,
                        style: TextStyle(
                          color: _isAlertTriggered ? alertColor : safeColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // 音声監視トグルボタン
              ElevatedButton.icon(
                onPressed: _toggleMonitoring,
                icon: Icon(_isListening ? Icons.stop_circle : Icons.fiber_manual_record),
                label: Text(
                  _isListening ? "リアルタイム常時監視を停止" : "リアルタイム常時音声監視を開始 (WAKE_LOCK)",
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isListening ? Colors.red.shade900 : const Color(0xFF047857),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),

              const SizedBox(height: 16),
              const Text("【検知音声・テキストストリーム】",
                  style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Container(
                height: 120,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E1E),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: Colors.white12),
                ),
                child: SingleChildScrollView(
                  child: Text(
                    _recognizedText,
                    style: const TextStyle(fontSize: 13, height: 1.4, color: Colors.white),
                  ),
                ),
              ),

              const SizedBox(height: 16),
              const Text("【LUCK NUNG ROI BAAN：AI監査ログ】",
                  style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Container(
                height: 200,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: _isAlertTriggered ? Colors.redAccent.withOpacity(0.5) : Colors.white12,
                  ),
                ),
                child: SingleChildScrollView(
                  child: Text(
                    _aiAnalysisLog,
                    style: TextStyle(
                      color: _isAlertTriggered ? Colors.orangeAccent : Colors.white70,
                      fontFamily: 'monospace',
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isAnalyzing ? null : _simulateSafeDialogue,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF374151),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                      child: const Text("日常会話テスト", style: TextStyle(fontSize: 12)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isAnalyzing ? null : _simulateTraffickingDialogue,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF991B1B),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                      child: const Text("人身売買テスト",
                          style: TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
